#!/usr/bin/env python3
"""
LAP Audit Pack Verification Script

Verifies the cryptographic integrity of an audit pack:
1. Evidence hash matches (canonical JSON per manifest)
2. Decision hash matches
3. External approval signature (if present)
4. Capability token signature (if present)
5. Receipt signatures
6. Chain integrity (receipts link correctly)
7. Hash commitments (params/result/response) if invocations.json present

Usage:
    python verify.py [audit_pack_directory] [--allow-no-crypto]

If no directory specified, uses current directory.

Security note:
    This script FAILS CLOSED if `cryptography` is not installed, unless you
    explicitly pass `--allow-no-crypto` (hash-only verification).
"""

import argparse
import json
import hashlib
import base64
import sys
from pathlib import Path


def canonical_json_dumps_v1(obj) -> str:
    """Canonical JSON v1 (legacy/permissive)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def canonical_json_dumps_v2(obj) -> str:
    """Canonical JSON v2 (strict)."""
    # Strict JSON: reject NaN/Infinity so hashes match cross-language verifiers.
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def canonical_json_dumps(obj, version: str = "v2") -> str:
    v = str(version or "v2").lower().strip()
    if v in ("v1", "1", "legacy"):
        return canonical_json_dumps_v1(obj)
    if v in ("v2", "2", "strict"):
        return canonical_json_dumps_v2(obj)
    raise ValueError(f"Unknown canonical JSON version: {version!r} (expected v1 or v2)")


# Try to import cryptography for Ed25519
CRYPTO_AVAILABLE = True
CRYPTO_IMPORT_ERROR = None
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
except Exception as e:
    CRYPTO_AVAILABLE = False
    CRYPTO_IMPORT_ERROR = str(e)

# Set by CLI flag
ALLOW_NO_CRYPTO = False


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_hash_encode(components: list) -> bytes:
    """Length-prefixed encoding for hash inputs."""
    result = b""
    for component in components:
        encoded = str(component).encode("utf-8")
        length_bytes = len(encoded).to_bytes(8, byteorder="big")
        result += length_bytes + encoded
    return result


def verify_ed25519(public_key_hex: str, message: bytes, signature: bytes) -> bool:
    """Verify Ed25519 signature (fail closed unless explicitly allowed)."""
    if not CRYPTO_AVAILABLE:
        return True if ALLOW_NO_CRYPTO else False
    try:
        public_key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(public_key_hex))
        public_key.verify(signature, message)
        return True
    except Exception as e:
        print(f"  Signature verification error: {e}")
        return False


def load_json_file(path: Path) -> dict:
    """Load JSON file."""
    with open(path) as f:
        return json.load(f)


def verify_evidence(pack_dir: Path, expected_hash: str, canon_version: str) -> tuple:
    """Verify evidence hash."""
    evidence_path = pack_dir / "evidence.json"
    if not evidence_path.exists():
        return False, "evidence.json not found"

    evidence = load_json_file(evidence_path)
    canonical = canonical_json_dumps(evidence, version=canon_version)
    actual_hash = sha256_hex(canonical.encode("utf-8"))

    if actual_hash == expected_hash:
        return True, f"Evidence hash verified ({canon_version}): {actual_hash[:16]}..."
    else:
        return False, f"Evidence hash mismatch ({canon_version}): expected {expected_hash[:16]}..., got {actual_hash[:16]}..."


def verify_decision(pack_dir: Path, expected_hash: str, evidence_hash: str, action_id: str) -> tuple:
    """Verify decision hash."""
    decision_path = pack_dir / "decision.json"
    if not decision_path.exists():
        return False, "decision.json not found"

    decision = load_json_file(decision_path)

    # Decision hash is bound to the audit pack's action_id (from manifest).
    components = [
        action_id,
        evidence_hash,
        decision.get("outcome", ""),
        decision.get("tier", ""),
        decision.get("reason", ""),
    ]
    actual_hash = sha256_hex(safe_hash_encode(components))

    if actual_hash == expected_hash:
        return True, f"Decision hash verified: {actual_hash[:16]}..."
    else:
        return False, f"Decision hash mismatch: expected {expected_hash[:16]}..., got {actual_hash[:16]}..."


def verify_approval(pack_dir: Path, trusted_keys: dict) -> tuple:
    """Verify external approval signature."""
    approval_path = pack_dir / "external_approval.json"
    if not approval_path.exists():
        return True, "No external approval (optional)"

    approval = load_json_file(approval_path)

    key_id = approval.get("key_id", "")
    public_key = trusted_keys.get(key_id)

    if not public_key:
        return False, f"Untrusted key_id: {key_id}"

    # Recompute signature payload
    components = [
        approval["action_id"],
        approval["evidence_hash"],
        approval["reviewer_id"],
        approval["reviewer_type"],
        approval["decision"],
        f"{approval['confidence']:.8f}",
        approval["reasoning"],
        ",".join(sorted(approval.get("conditions", []))),
        approval["reviewed_at_utc"],
    ]
    payload = safe_hash_encode(components)

    signature = base64.b64decode(approval["signature"])

    if verify_ed25519(public_key, payload, signature):
        return True, f"External approval signature verified (key: {key_id})"
    else:
        return False, "External approval signature INVALID"


def verify_token(pack_dir: Path, trusted_keys: dict) -> tuple:
    """Verify capability token signature."""
    token_path = pack_dir / "token.json"
    if not token_path.exists():
        return True, "No capability token (optional)"

    token = load_json_file(token_path)

    key_id = token.get("key_id", "")
    public_key = trusted_keys.get(key_id)

    if not public_key:
        return False, f"Untrusted key_id: {key_id}"

    # Recompute token signature payload
    payload_obj = token.get("payload") or {}
    components = [
        payload_obj.get("sub", ""),
        payload_obj.get("action_id", ""),
        payload_obj.get("evidence_hash", ""),
        payload_obj.get("decision_hash", ""),
        payload_obj.get("tier", ""),
        ",".join(payload_obj.get("allowed_tools", []) or []),
        ",".join(payload_obj.get("allowed_ops", []) or []),
        str(payload_obj.get("budget_tokens", "")),
        str(payload_obj.get("budget_cost", "")),
        str(payload_obj.get("exp", "")),
        payload_obj.get("nonce", ""),
        str(payload_obj.get("counter", "")),
        str(payload_obj.get("nonce_required", False)),
        str(payload_obj.get("counter_required", False)),
        payload_obj.get("params_hash", ""),
        payload_obj.get("sid", ""),
        token.get("signed_at_utc", ""),
    ]
    payload = safe_hash_encode(components)

    signature = base64.b64decode(token.get("signature", ""))

    if verify_ed25519(public_key, payload, signature):
        return True, f"Token signature verified (key: {key_id})"
    else:
        return False, "Token signature INVALID"


def verify_receipts(pack_dir: Path, trusted_keys: dict, token_jti: str | None = None, receipt_profile: str = "v1") -> tuple:
    """Verify receipt signatures and chain integrity.

    Note: this verifier is intentionally lightweight and may lag behind the
    stricter `lap_verify` CLI. For tool-invocation receipts, we prefer using
    the receipt object's own canonical payload/hash methods to avoid drift.
    """
    receipts_path = pack_dir / "receipts.json"
    if not receipts_path.exists():
        return True, "No receipts (optional)"

    receipts = load_json_file(receipts_path)
    if not isinstance(receipts, list):
        return False, "receipts.json must contain a list"

    # Optional invocations commitments
    invocations_path = pack_dir / "invocations.json"
    invocations = {}
    if invocations_path.exists():
        inv_list = load_json_file(invocations_path)
        if isinstance(inv_list, list):
            for item in inv_list:
                rid = str(item.get("receipt_id", ""))
                if rid:
                    invocations[rid] = item

    from lap_gateway.receipts import ToolInvocationReceipt, compute_decision_binding

    prev_hash = ""
    for i, receipt in enumerate(receipts):
        # Determine receipt type (tool invocation vs denial)
        if "tool_name" not in receipt:
            # Denial receipt
            key_id = receipt.get("key_id", "")
            public_key = trusted_keys.get(key_id)
            if not public_key:
                return False, f"Denial receipt {i}: untrusted key_id {key_id}"

            components = [
                receipt["receipt_id"],
                receipt["action_id"],
                receipt["evidence_hash"],
                receipt["decision_hash"],
                receipt["outcome"],
                receipt["tier"],
                receipt["reason"],
                receipt["denied_at_utc"],
            ]
            payload = safe_hash_encode(components)
            signature = base64.b64decode(receipt["signature"])

            if not verify_ed25519(public_key, payload, signature):
                return False, f"Denial receipt {i}: signature INVALID"
            continue

        # Tool invocation receipt
        if token_jti and receipt.get("token_jti") and receipt.get("token_jti") != token_jti:
            return False, f"Receipt {i}: token_jti mismatch"

        rcpt = ToolInvocationReceipt.from_dict(receipt)

        # Chain linking
        if rcpt.prev_receipt_hash != prev_hash:
            return False, f"Receipt {i}: chain broken (expected prev {prev_hash[:16]}...)"

        key_id = receipt.get("key_id", "")
        public_key = trusted_keys.get(key_id)

        if not public_key:
            return False, f"Receipt {i}: untrusted key_id {key_id}"

        # Enforce decision_binding when receipt_profile=v2
        if receipt_profile == "v2":
            if not rcpt.decision_binding:
                return False, f"Receipt {i}: decision_binding missing (receipt_profile=v2)"
            expected_db = compute_decision_binding(
                decision_hash=rcpt.decision_hash,
                token_jti=rcpt.token_jti,
                action_id=rcpt.action_id,
                sid=rcpt.sid,
                tool_name=rcpt.tool_name,
                operation=rcpt.operation,
                params_hash=rcpt.params_hash,
                prev_receipt_hash=rcpt.prev_receipt_hash,
                evidence_hash=rcpt.evidence_hash,
            )
            if rcpt.decision_binding != expected_db:
                return False, f"Receipt {i}: decision_binding mismatch"

        payload = rcpt.compute_signature_payload()
        signature = rcpt.signature

        if not verify_ed25519(public_key, payload, signature):
            return False, f"Receipt {i}: signature INVALID"

        # Recompute receipt hash (do not trust embedded receipt_hash)
        computed_receipt_hash = rcpt.compute_receipt_hash()
        embedded = receipt.get("receipt_hash", "")
        if embedded and embedded != computed_receipt_hash:
            return False, f"Receipt {i}: receipt_hash mismatch"

        # Verify hash commitments when full invocations are provided
        inv = invocations.get(str(receipt.get("receipt_id", "")))
        if inv:
            def canon(obj):
                # Receipts commit tool I/O using Canonical JSON v1 (legacy/permissive).
                return canonical_json_dumps(obj, version="v1")

            if "params" in inv:
                # Hash-commit is over a params envelope to prevent tool/op mix-and-match.
                params_env = {"tool_name": rcpt.tool_name, "operation": rcpt.operation, "params": inv["params"]}
                if sha256_hex(canon(params_env).encode("utf-8")) != rcpt.params_hash:
                    return False, f"Receipt {i}: params_hash mismatch"
            if "result" in inv:
                if sha256_hex(canon(inv["result"]).encode("utf-8")) != receipt.get("result_hash"):
                    return False, f"Receipt {i}: result_hash mismatch"
            if "response_envelope" in inv:
                if sha256_hex(canon(inv["response_envelope"]).encode("utf-8")) != receipt.get("response_hash", ""):
                    return False, f"Receipt {i}: response_hash mismatch"

        prev_hash = computed_receipt_hash

    return True, f"All {len(receipts)} receipt(s) verified"


def main(pack_dir: Path, *, allow_no_crypto: bool = False):
    """Main verification routine."""
    global ALLOW_NO_CRYPTO
    ALLOW_NO_CRYPTO = bool(allow_no_crypto)

    print(f"
LAP Audit Pack Verification")
    print(f"Directory: {pack_dir}")
    print("=" * 50)

    if not CRYPTO_AVAILABLE and not ALLOW_NO_CRYPTO:
        print("ERROR: cryptography library is not installed.")
        if CRYPTO_IMPORT_ERROR:
            print(f"  Import error: {CRYPTO_IMPORT_ERROR}")
        print("Install with: pip install cryptography")
        print("Or re-run with: python verify.py <dir> --allow-no-crypto  (hash-only; signatures skipped)")
        return False

    if not CRYPTO_AVAILABLE and ALLOW_NO_CRYPTO:
        print("WARNING: cryptography not installed; proceeding in HASH-ONLY mode (signatures skipped).")
        print("         Install with: pip install cryptography")
        print()

    # Load manifest
    manifest_path = pack_dir / "manifest.json"
    if not manifest_path.exists():
        print("ERROR: manifest.json not found")
        return False

    manifest = load_json_file(manifest_path)
    canon_ver = str(manifest.get("canonical_json_version", "v1") or "v1")
    receipt_profile = str(manifest.get("receipt_profile", "v1") or "v1").lower().strip()

    print(f"Action ID: {manifest['action_id']}")
    print(f"Evidence Hash: {manifest['evidence_hash'][:16]}...")
    print(f"Decision Hash: {manifest['decision_hash'][:16]}...")
    print(f"Canonical JSON: {canon_ver}")
    print()

    # Load trusted keys
    keys_path = pack_dir / "trusted_keys.json"
    trusted_keys = load_json_file(keys_path) if keys_path.exists() else {}
    print(f"Trusted keys: {list(trusted_keys.keys())}")
    print()

    all_passed = True

    # Verify evidence
    print("1. Verifying evidence hash...")
    ok, msg = verify_evidence(pack_dir, manifest["evidence_hash"], canon_ver)
    print(f"   {'✓' if ok else '✗'} {msg}")
    all_passed = all_passed and ok

    # Verify decision
    print("2. Verifying decision hash...")
    ok, msg = verify_decision(pack_dir, manifest["decision_hash"], manifest["evidence_hash"], manifest["action_id"])
    print(f"   {'✓' if ok else '✗'} {msg}")
    all_passed = all_passed and ok

    # Verify external approval
    print("3. Verifying external approval...")
    ok, msg = verify_approval(pack_dir, trusted_keys)
    print(f"   {'✓' if ok else '✗'} {msg}")
    all_passed = all_passed and ok

    # Verify token
    print("4. Verifying capability token...")
    ok, msg = verify_token(pack_dir, trusted_keys)
    print(f"   {'✓' if ok else '✗'} {msg}")
    all_passed = all_passed and ok

    # Get token jti for receipt verification
    token_path = pack_dir / "token.json"
    token_jti = None
    if token_path.exists():
        token = load_json_file(token_path)
        token_jti = token.get("jti")

    # Verify receipts
    print("5. Verifying receipts...")
    ok, msg = verify_receipts(pack_dir, trusted_keys, token_jti, receipt_profile)
    print(f"   {'✓' if ok else '✗'} {msg}")
    all_passed = all_passed and ok

    print()
    print("=" * 50)
    if all_passed:
        print("VERIFICATION PASSED ✓")
        if not CRYPTO_AVAILABLE and ALLOW_NO_CRYPTO:
            print("NOTE: Hashes verified, but signatures were NOT checked.")
        else:
            print("This audit pack is cryptographically valid.")
    else:
        print("VERIFICATION FAILED ✗")
        print("This audit pack has integrity issues.")

    return all_passed


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify a LAP audit pack (offline).")
    parser.add_argument("pack_dir", nargs="?", default=".", help="Path to extracted audit pack directory (default: .)")
    parser.add_argument(
        "--allow-no-crypto",
        action="store_true",
        help="Allow running without cryptography (hash-only; signatures skipped).",
    )
    args = parser.parse_args()

    pack_dir = Path(args.pack_dir)
    success = main(pack_dir, allow_no_crypto=args.allow_no_crypto)
    sys.exit(0 if success else 1)