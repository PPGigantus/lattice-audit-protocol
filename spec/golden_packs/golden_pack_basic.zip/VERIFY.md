# LAP Audit Pack Verification

This directory contains a cryptographically verifiable audit pack for a LAP-governed action.

## Quick Verification

```bash
python verify.py
```

Or specify a directory:

```bash
python verify.py /path/to/audit_pack
```

## Contents

| File | Description |
|------|-------------|
| `manifest.json` | Pack metadata with action_id, evidence_hash, decision_hash |
| `evidence.json` | Original evidence submitted for evaluation |
| `decision.json` | LAP decision record |
| `external_approval.json` | External reviewer approval (if T3) |
| `token.json` | Capability token issued (if approved) |
| `receipts.json` | Signed receipts for tool invocations |
| `invocations.json` | Optional full params/result/response objects for hash commitment checks |
| `trusted_keys.json` | Public keys for signature verification |
| `verify.py` | Verification script |
| `VERIFY.md` | This file |

## What Gets Verified

1. **Evidence Hash**: The evidence content matches its claimed hash
2. **Decision Hash**: The decision binds correctly to action_id + evidence_hash + outcome
3. **External Approval**: Ed25519 signature from trusted reviewer key
4. **Capability Token**: Ed25519 signature from gateway key
5. **Receipts**: 
   - Ed25519 signatures valid
   - Chain integrity (each receipt links to previous)
   - Token binding (receipts tied to correct token)
   - Hash commitments (params/result/response) if `invocations.json` provided

## Security Properties

- **Unforgeable**: Ed25519 signatures cannot be forged without private keys
- **Tamper-evident**: Any modification breaks hash/signature verification
- **Offline verifiable**: No database or network access required
- **Evidence-bound**: Approvals tied to specific evidence content, not just action_id

## Requirements

For full signature verification:

```bash
pip install cryptography
```

By default, verification FAILS CLOSED if `cryptography` is not installed.

If you explicitly want *hash-only* verification (signatures skipped), run the bundled `verify.py` with `--allow-no-crypto`.

## Trust Model

The `trusted_keys.json` file contains public keys that are trusted for verification.
You should verify these keys through an out-of-band channel (e.g., published on
your organization's security page).
